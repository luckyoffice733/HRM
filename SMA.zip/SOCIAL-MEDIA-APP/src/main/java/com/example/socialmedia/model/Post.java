package com.example.socialmedia.model;

import jakarta.persistence.*;
import java.sql.Timestamp;
import java.util.List;

@Entity
public class Post {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long postID;

    @ManyToOne
    @JoinColumn(name = "userID")
    private User user;

    private String content;
    private Timestamp postTimestamp;

    @OneToMany(mappedBy = "post")
    private List<Comment> comments;

    @OneToMany(mappedBy = "post")
    private List<Likes> likes;

    // Getters and Setters
}