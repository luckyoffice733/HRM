package com.example.socialmedia.model;

import jakarta.persistence.*;
import java.util.List;

@Entity
public class Group {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long groupID;

    private String groupName;

    @ManyToOne
    @JoinColumn(name = "admin")
    private User admin;

    @OneToMany(mappedBy = "userID")
    private List<User> members;

    // Getters and Setters
}