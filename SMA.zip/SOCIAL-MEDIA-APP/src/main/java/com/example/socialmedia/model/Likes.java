package com.example.socialmedia.model;

import jakarta.persistence.*;
import java.sql.Timestamp;

@Entity
public class Likes {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long likeID;

    @ManyToOne
    @JoinColumn(name = "postID")
    private Post post;

    @ManyToOne
    @JoinColumn(name = "userID")
    private User user;

    private Timestamp likeTimestamp;

    // Getters and Setters
}