package com.example.socialmedia.controller;

import com.example.socialmedia.model.Friend;
import com.example.socialmedia.service.FriendService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/friends")
public class FriendController {

    @Autowired
    private FriendService friendService;

    @GetMapping
    public List<Friend> getAllFriends() {
        return friendService.getAllFriends();
    }

    @PostMapping
    public Friend createFriend(@RequestBody Friend friend) {
        return friendService.createFriend(friend);
    }

    // Add other CRUD endpoints
}