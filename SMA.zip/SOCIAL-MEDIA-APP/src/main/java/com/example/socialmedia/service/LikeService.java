package com.example.socialmedia.service;

import com.example.socialmedia.model.Likes;
import com.example.socialmedia.repository.LikeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LikeService {

    @Autowired
    private LikeRepository likeRepository;

    public List<Likes> getAllLikes() {
        return likeRepository.findAll();
    }

    public Likes createLike(Likes like) {
        return likeRepository.save(like);
    }

    // Add other CRUD methods
}