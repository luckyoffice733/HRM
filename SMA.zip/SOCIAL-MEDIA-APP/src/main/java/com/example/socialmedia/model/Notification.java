package com.example.socialmedia.model;

import jakarta.persistence.*;
import java.sql.Timestamp;

@Entity
public class Notification {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long notificationID;

    @ManyToOne
    @JoinColumn(name = "userID")
    private User user;

    private String content;
    private Timestamp notificationTimestamp;

    // Getters and Setters
}