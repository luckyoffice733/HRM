package com.example.socialmedia.controller;

import com.example.socialmedia.model.Likes;
import com.example.socialmedia.service.LikeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/likes")
public class LikeController {

    @Autowired
    private LikeService likeService;

    @GetMapping
    public List<Likes> getAllLikes() {
        return likeService.getAllLikes();
    }

    @PostMapping
    public Likes createLike(@RequestBody Likes like) {
        return likeService.createLike(like);
    }

    // Add other CRUD endpoints
}