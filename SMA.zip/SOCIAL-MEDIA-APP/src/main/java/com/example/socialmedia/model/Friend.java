package com.example.socialmedia.model;

import jakarta.persistence.*;

@Entity
public class Friend {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long friendID;

    @ManyToOne
    @JoinColumn(name = "userID")
    private User user;

    @Enumerated(EnumType.STRING)
    private FriendStatus status;

    // Getters and Setters
}

enum FriendStatus {
    PENDING, ACCEPTED, REJECTED
}