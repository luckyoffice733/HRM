package com.example.socialmedia.repository;

import com.example.socialmedia.model.Message;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MessageRepository extends JpaRepository<Message, Long> {
}