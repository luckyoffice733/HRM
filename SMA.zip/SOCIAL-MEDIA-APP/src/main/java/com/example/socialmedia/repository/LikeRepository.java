package com.example.socialmedia.repository;

import com.example.socialmedia.model.Likes;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LikeRepository extends JpaRepository<Likes, Long> {
}