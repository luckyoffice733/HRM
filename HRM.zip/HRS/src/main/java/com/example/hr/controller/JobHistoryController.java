package com.example.hr.controller;

import com.example.hr.model.JobHistory;
import com.example.hr.service.JobHistoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/job-histories")
public class JobHistoryController {

    @Autowired
    private JobHistoryService jobHistoryService;

    @GetMapping
    public List<JobHistory> getAllJobHistories() {
        return jobHistoryService.getAllJobHistories();
    }

    @PostMapping
    public JobHistory createJobHistory(@RequestBody JobHistory jobHistory) {
        return jobHistoryService.createJobHistory(jobHistory);
    }

    // Add other CRUD endpoints
}