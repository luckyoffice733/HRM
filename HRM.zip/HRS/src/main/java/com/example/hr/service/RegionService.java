package com.example.hr.service;

import com.example.hr.model.Region;
import com.example.hr.repository.RegionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RegionService {

    @Autowired
    private RegionRepository regionRepository;

    public List<Region> getAllRegions() {
        return regionRepository.findAll();
    }

    public Region createRegion(Region region) {
        return regionRepository.save(region);
    }

    // Add other CRUD methods
}