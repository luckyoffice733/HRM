package com.example.hr.service;

import com.example.hr.model.JobHistory;
import com.example.hr.repository.JobHistoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class JobHistoryService {

    @Autowired
    private JobHistoryRepository jobHistoryRepository;

    public List<JobHistory> getAllJobHistories() {
        return jobHistoryRepository.findAll();
    }

    public JobHistory createJobHistory(JobHistory jobHistory) {
        return jobHistoryRepository.save(jobHistory);
    }

    // Add other CRUD methods
}